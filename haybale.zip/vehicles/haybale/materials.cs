
singleton Material(haybale)
{
    mapTo = "haybale";
    diffuseMap[0] = "haybale_d.dds";
    specularMap[0] = "haybale_s.dds";
    normalMap[0] = "haybale_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "64";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(haybale2)
{
    mapTo = "haybale2";
    diffuseMap[0] = "haybale2_d.dds";
    specularMap[0] = "haybale_s.dds";
    normalMap[0] = "haybale_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "64";
    //subSurface[0] = "1";
    //subSurfaceColor[0] = "0.996078 0.992157 0.992157 1";
    //subSurfaceRolloff[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(haybale3)
{
    mapTo = "haybale3";
    diffuseMap[0] = "haybale3_d.dds";
    specularMap[0] = "haybale_s.dds";
    normalMap[0] = "haybale_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "64";
    subSurface[0] = "1";
    subSurfaceColor[0] = "0.996078 0.992157 0.992157 1";
    subSurfaceRolloff[0] = "0.4";
    materialTag0 = "beamng"; materialTag1 = "object";
    doubleSided = "1";
};

