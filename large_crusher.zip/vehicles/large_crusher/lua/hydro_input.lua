-- This Source Code Form is subject to the terms of the bCDDL, v. 1.1.
-- If a copy of the bCDDL was not distributed with this
-- file, You can obtain one at http://beamng.com/bCDDL-1.1.txt
local M = {}

local function onReset()
    electrics.values['crusher'] = 0
end

local function updateGFX(dt)
    electrics.values['crusher'] = round(electrics.values['throttle_input'] - electrics.values['brake_input'])
end

-- public interface
M.onInit    = onInit
M.onReset   = onReset
M.updateGFX = updateGFX

return M
