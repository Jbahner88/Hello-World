singleton Material(barrier_01)
{
    mapTo = "barrier_01";
    diffuseMap[0] = "barrier_01_d.dds";
    specularMap[0] = "barrier_01_s.dds";
    normalMap[0] = "barrier_01_n.dds";
    specularPower[0] = "1";
    pixelSpecular[0] = "0";
    diffuseColor[0] = "0.992157 0.992157 0.992157 1";
    materialTag0 = "beamng";
    materialTag1 = "Industrial";
};
