singleton Material(large_roller_tex)
{
    mapTo = "large_roller_tex";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/large_roller/large_roller_N.dds";
    diffuseMap[1] = "vehicles/large_roller/large_roller_D.dds";
    normalMap[1] = "vehicles/large_roller/large_roller_N.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.75";
    specularPower[0] = "16";
    specularPower[1] = "16";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
