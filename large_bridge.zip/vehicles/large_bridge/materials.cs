
singleton Material(large_bridge_bridge_foundations)
{
    mapTo = "bridge_foundations";
    diffuseColor[0] = "0.80 0.80 0.80 1";
    diffuseMap[0] = "large_bridge_asphalt_d.dds";
    specularPower[0] = "1";
    specularMap[0] = "large_bridge_asphalt_s.dds";
    doubleSided = "1";
    translucentBlendOp = "None";
};

singleton Material(large_bridge_bridge_tiles)
{
    mapTo = "bridge_tiles";
    diffuseMap[0] = "large_bridge_wood_d.dds";
    doubleSided = "0";
    translucentBlendOp = "None";
    specularMap[0] = "large_bridge_wood_s.dds";
    normalMap[0] = "large_bridge_wood_n.dds";
    specularPower[0] = "1";
    useAnisotropic[0] = "1";
};
