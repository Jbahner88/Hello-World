
singleton Material(flipramp_01a)
{
    mapTo = "flipramp_01a";
    diffuseMap[1] = "flipramp_01a_d.dds";
    specularMap[1] = "flipramp_01a_s.dds";
    normalMap[1] = "flipramp_01a_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "flipramp_01a_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "object";
};
