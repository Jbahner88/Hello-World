
singleton Material(example_crusher_angle_protractor)
{
    mapTo = "angle_protractor";
    doubleSided = "1";
    specularPower[0] = "1";
    useAnisotropic[0] = "1";
    diffuseMap[0] = "vehicles/large_angletester/large_angletester.jpg";
    translucent = "0";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
};

singleton Material(example_crusher_angle_floor)
{
    mapTo = "angle_floor";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    diffuseMap[1] = "vehicles/common/null.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.1 0.1 0.1 0.7";
    specularPower[0] = "16";
    specularPower[1] = "16";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "0";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
