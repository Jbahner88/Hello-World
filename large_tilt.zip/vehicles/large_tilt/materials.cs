
singleton Material(tilt_planks)
{
    mapTo = "tilt_planks";
    diffuseMap[0] = "levels/port/art/shapes/buildings/ind_planks_01_d.dds";
    normalMap[0] = "levels/port/art/shapes/buildings/ind_planks_01_n.dds";
    specularMap[0] = "levels/port/art/shapes/buildings/ind_planks_01_s.dds";
    specularPower[0] = "1";
    specularStrength[0] = "0.294118";
    pixelSpecular[0] = "0";
    useAnisotropic[0] = "1";
    alphaTest = "1";
    alphaRef = "121";
};

singleton Material(tilt_rustymetal)
{
    mapTo = "tilt_rustymetal";
    diffuseMap[0] = "levels/port/art/shapes/buildings/ind_bld_rustymetal_01_d.dds";
    detailMap[0] = "levels/port/art/shapes/buildings/detail_grunge_02.dds";
    detailScale[0] = "0.1 0.1";
    normalMap[0] = "levels/port/art/shapes/buildings/ind_bld_rustymetal_01_n.dds";
    specularPower[0] = "1";
    pixelSpecular[0] = "1";
    specularMap[0] = "levels/port/art/shapes/buildings/ind_bld_rustymetal_01_s.dds";
    translucentBlendOp = "None";
};
