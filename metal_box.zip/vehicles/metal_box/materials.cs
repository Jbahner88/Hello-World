
singleton Material(metal_box)
{
    mapTo = "metal_box";
    diffuseMap[1] = "metal_box_D.dds";
    specularMap[1] = "metal_box_S.dds";
    normalMap[1] = "metal_box_N.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "metal_box_N.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(metal_box_decals)
{
    mapTo = "metal_box_decals";
    diffuseMap[1] = "metal_box_decals.dds";
    specularMap[1] = "vehicles/common/null.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0 0 0 0";
    diffuseColor[1] = "1 1 1 0.6";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle"; materialTag2 = "decal";
    translucentZWrite = "1";
};
