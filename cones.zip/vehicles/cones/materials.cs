singleton Material(cone_01a)
{
    mapTo = "cone_01a";
    diffuseMap[0] = "cone_01a_d.dds";
    specularMap[0] = "cone_01a_s.dds";
    normalMap[0] = "cone_01a_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1.5 1.5 1.5 1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "object";
};
