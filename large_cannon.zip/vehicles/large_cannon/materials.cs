
singleton Material(catapult_cannon)
{
    mapTo = "cannon";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    diffuseMap[1] = "vehicles/large_cannon/large_cannon_d.dds";
    normalMap[1] = "vehicles/large_cannon/large_cannon_n.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.9";
    specularPower[0] = "16";
    specularPower[1] = "16";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(catapult_supports)
{
    mapTo = "supports";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    diffuseMap[1] = "vehicles/large_cannon/large_cannon_supports_d.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.9";
    specularPower[0] = "16";
    specularPower[1] = "16";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(catapult_ramp)
{
    mapTo = "ramp";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    diffuseMap[1] = "vehicles/large_cannon/large_cannon_ramp_d.dds";
    normalMap[1] = "vehicles/large_cannon/large_cannon_ramp_n.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.9";
    specularPower[0] = "16";
    specularPower[1] = "16";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
