singleton Material(kickplate_1)
{
    mapTo = "kickplate_1";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    diffuseMap[1] = "vehicles/common/null.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.0 0.0 0.0 0.8";
    specularPower[0] = "16";
    specularPower[1] = "16";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(kickplate_2)
{
    mapTo = "kickplate_2";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    diffuseMap[1] = "vehicles/common/null.dds";
    specularMap[1] = "vehicles/common/null.dds";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.2 0.2 0.2 0.7";
    specularPower[0] = "16";
    specularPower[1] = "16";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
